import java.util.ArrayList;
import javax.swing.ImageIcon;

public abstract class Pieces  implements Comparable{
	int id;//-1 wall(no class needed id will handle it doesnot move either), 
	       //0 for null is not used anywhere as id, 
	       //1 for B, 2 for G, 3 for R, 4 for Y, =>  5 chipB, 6 chpG, 7 chipR, 8 chipY
	ImageIcon img;
	boolean wall_top;
	boolean wall_left;
	boolean wall_bottom;
	boolean wall_right;
	
	
	 // Node members for convienience
     public Pieces parent;
     public int X, Y;
     public double g;
     public double h;
     void Node_For_Astar(Pieces parent, int xpos, int ypos, double G, double H) {
            this.parent = parent;
            this.X = xpos;
            this.Y = ypos;
            this.g = G;
            this.h = H;
    }
     // Compare by f value (g + h)
     @Override
    public int compareTo(Object o) {
         Pieces that = (Pieces) o;
         return (int)((this.g + this.h) - (that.g + that.h));
    }
	public abstract  ArrayList<Integer> Validate_Move(Pieces [][]pcs, int cX, int cY, int nX, int nY);
}
