import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Chip extends Pieces{

	private final String []path = {"images/target-blue-circle.png"  , "images/target-green-circle.png", 
	                               "images/target-red-circle.png"   , "images/target-yellow-circle.png",
	                               "images/target-blue-triangle.png", "images/target-green-triangle.png",
	                               "images/target-red-triangle.png" , "images/target-yellow-triangle.png",
	                               "images/target-blue-square.png"  , "images/target-green-square.png",
	                               "images/target-red-square.png"   , "images/target-yellow-square.png",
	                               "images/target-blue-star.png"    , "images/target-green-star.png",
	                               "images/target-red-star.png"    , "images/target-yellow-star.png",
	                               "images/target-whirlpool.png"
	                              }; 

	// 5 chipB, 6 chpG, 7 chipR, 8 chipY...
    public Chip(int ChipId, boolean top, boolean left, boolean bottom, boolean right) throws IOException{
     id = ChipId;
     
     img = new ImageIcon(ImageIO.read(new File(path[ChipId-5]))
				.getScaledInstance(30, 30, Image.SCALE_SMOOTH));//-5 because id sent from 5
     
    wall_top = top;
 	wall_left = left;
 	wall_bottom = bottom;
 	wall_right = right;
 	h = -1;
    }
    
	@Override
	public ArrayList<Integer> Validate_Move(Pieces[][] pcs, int cX, int cY, int nX, int nY) {
		// this piece remain at its position so no code
		return null;
	}

}
