import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Robot extends Pieces {
	
	private final String []path = {"images/robot-blue.png", "images/robot-green.png", 
			         "images/robot-red.png", "images/robot-yellow.png"}; 
	
	public Robot(int RoboId,  boolean top, boolean left, boolean bottom, boolean right) throws IOException{
		id = RoboId;
		
		img = new ImageIcon(ImageIO.read(new File(path[RoboId-1]))
				.getScaledInstance(45, 38, Image.SCALE_SMOOTH));//-1 because id sent from 1
		
		wall_top = top;
		wall_left = left;
		wall_bottom = bottom;
		wall_right = right;
		h = -1;
	}

	@Override
	public ArrayList<Integer> Validate_Move(Pieces[][] pcs, int cX, int cY, int nX, int nY) {
		
		ArrayList<Integer> status = new ArrayList<Integer>(3);
		status.add(-1);
		status.add(cX);
		status.add(cY);
		
		if( !((cX==nX && cY!=nY) || (cX!=nX && cY==nY)))
			return status;
		
		status.add(0);//rec move but can work or not..but if end is zero means cant work
		int i=cX,j=cY;
		if(cX==nX && cY < nY) {
			
			while(true) {//15
				j++;
				if(j>cY) status.set(0,1);
				
				if(j == Ricochet_Board.Cols-1) {
					status.set(2,j);break;
				}
				else if(check(pcs,i, j)) { //any obj found or wall
					status.set(2,j-1);
					break;
				}
			}	
		}
		
		else if(cX==nX && cY > nY) {
			
			while(true) {
				j--;
				if(j<cY) status.set(0,1);
				
				if(j==0) {
				   status.set(2,j);break;
				}
				else if(check(pcs,i, j)) { //any obj found
					status.set(2,j+1);
					break;
				}
			}	
		}
		
		else if(cY==nY && cX < nX) {
			
			while(true) {
				i++;
				if(i>cX) status.set(0,1);
				
				if(i == Ricochet_Board.Rows-1) {
					status.set(1,i); break;
				}
				else if(check(pcs,i, j)) { //any obj found
					status.set(1,i-1);
					break;//send max reach able loc
				}
			}
		}
		
		else {
			while(true) {
				i--;
				if(i<cX) status.set(0,1);
				
				if(i==0) {
					status.set(1,i);break;
				}
				else if(check(pcs,i, j)) { //any obj found
					status.set(1,i+1);
					break;
				}
			}
		}
		

		return status;//send max reach able loc
	}
	
	private boolean check(Pieces [][]pcs, int i, int j) {
		if(pcs[i][j] != null)//something there
			return true;
		return false;
	}
}
