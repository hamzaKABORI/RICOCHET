import java.util.ArrayList;

public class empty extends Pieces{

	public empty(){

	}
	public empty(boolean top, boolean left, boolean bottom, boolean right){
		id = 0;//empty
		img = null;
		wall_top = top;
		wall_left = left;
		wall_bottom = bottom;
		wall_right = right;
		h = -1;
	}

	@Override
	public ArrayList<Integer> Validate_Move(Pieces[][] pcs, int cX, int cY, int nX, int nY) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
